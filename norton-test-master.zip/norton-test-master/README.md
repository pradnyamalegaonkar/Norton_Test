# norton-test

## Assumption
1. by recent PII, i assumed i need to fetcht the latest update on the accountId
2. i assumed client will provide all the information which is not updated as well with the updated information.


## Follow up questions answers
1. it doesnt do validation on the data while inserting, so it doesnt handle malformed or corrupt data, i could a add a layer for validation while adding but it would require more expected time given to solve this problem.
2. yes its optimized as recentUpdate has time complexity of O(1).
3. we could ask for other information like fname, lname and address which could make up for accountId.
4. need more clarification on this question

## Design
1. created a stack for each account.
2. whenever update happens,i stored the record on top of the stack.
3. for recent update i just check the top of the stack for the given accountId.
4. AccountRepo is the interface which can be used by restcontroller endpoint to call the api.

## Run
1. Checkout the unit test for add and recentUpdate functionality.
