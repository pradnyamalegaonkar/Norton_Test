package com.norton.account;

import com.google.gson.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class AccountRepoImpl implements AccountRepo{

    private HashMap<String, Stack<JsonObject>> accountDetails= new HashMap<>();

    private static Logger logger = LoggerFactory.getLogger(AccountRepoImpl.class);

    @Override
    public JsonObject recentUpdate(Number accountNo) {
        return accountDetails.getOrDefault(accountNo.toString(), new Stack<>()).peek().getAsJsonObject();
    }

    @Override
    public boolean add(JsonObject record) {
        try {
            Stack<JsonObject> records = accountDetails.computeIfAbsent(record.get("account_id").getAsString(), k -> new Stack<>());
            records.push(record);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }

        return true;
    }
}
