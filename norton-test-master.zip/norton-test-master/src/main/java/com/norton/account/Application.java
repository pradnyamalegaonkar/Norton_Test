package com.norton.account;

public class Application {

    public static void main(String[] args) {
        System.out.println("Checkout Unit test to run the application");
    }
}
