package com.norton.account;

import com.google.gson.JsonObject;

public interface AccountRepo {
    JsonObject recentUpdate(Number accountNo);
    boolean add(JsonObject record);

}
