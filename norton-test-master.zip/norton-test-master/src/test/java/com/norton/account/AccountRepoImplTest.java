package com.norton.account;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class AccountRepoImplTest {

    @Test
    public void testAdd() {
        AccountRepoImpl accountRepo = new AccountRepoImpl();
        JsonObject customer1 = JsonParser.parseString("{\"account_id\" : 1121345, \"event_date\": \"2017-08-24\", \"account_standing\": \"G\", \"account_information\":\n" +
                "{\"first_name\": \"John\", \"last_name\": \"Doe\", \"date_of_birth\": \"1986-08-18\", \"address\": {\"street_number\": \"123\",\n" +
                "\"street_name\": \"Main Street\", \"city\": \"Centerville\", \"state\": \"CA\", \"zip_code\": \"91111\"}, \"email_address\":\n" +
                "\"john_doe@gmail.com\"}}").getAsJsonObject();

        assertTrue(accountRepo.add(customer1));
    }

    @Test
    public void testMultipleAdd() {
        AccountRepoImpl accountRepo = new AccountRepoImpl();
        JsonObject customer1 = JsonParser.parseString("{\"account_id\" : 1121345, \"event_date\": \"2017-08-24\", \"account_standing\": \"G\", \"account_information\":\n" +
                "{\"first_name\": \"John\", \"last_name\": \"Doe\", \"date_of_birth\": \"1986-08-18\", \"address\": {\"street_number\": \"123\",\n" +
                "\"street_name\": \"Main Street\", \"city\": \"Centerville\", \"state\": \"CA\", \"zip_code\": \"91111\"}, \"email_address\":\n" +
                "\"john_doe@gmail.com\"}}").getAsJsonObject();

        assertTrue(accountRepo.add(customer1));

        JsonObject customer2 = JsonParser.parseString("{\"account_id\" : 1454581, \"event_date\": \"2018-01-09\", \"account_standing\": \"B\", \"account_information\":\n" +
                "{\"first_name\": \"Jane\", \"last_name\": \"Smith\", \"date_of_birth\": \"1975-09-09\", \"address\": {\"street_number\":\n" +
                "\"345\", \"street_name\": \"Oak Drive\", \"unit_number\": \"12A\", \"city\": \"Mount Pleasant\", \"state\": \"CA\", \"zip_code\":\n" +
                "\"90010\"}, \"email_address\": \"jane_smith@yahoo.com\"}}").getAsJsonObject();

        assertTrue(accountRepo.add(customer2));

        assertEquals("1121345", accountRepo.recentUpdate(1121345).get("account_id").getAsString());
        assertEquals("1454581", accountRepo.recentUpdate(1454581).get("account_id").getAsString());
    }

    @Test
    public void testRecentUpdate() {
        AccountRepoImpl accountRepo = new AccountRepoImpl();
        JsonObject customer1 = JsonParser.parseString("{\"account_id\" : 1121345, \"event_date\": \"2017-08-24\", \"account_standing\": \"G\", \"account_information\":\n" +
                "{\"first_name\": \"John\", \"last_name\": \"Doe\", \"date_of_birth\": \"1986-08-18\", \"address\": {\"street_number\": \"123\",\n" +
                "\"street_name\": \"Main Street\", \"city\": \"Centerville\", \"state\": \"CA\", \"zip_code\": \"91111\"}, \"email_address\":\n" +
                "\"john_doe@gmail.com\"}}").getAsJsonObject();

        assertTrue(accountRepo.add(customer1));

        JsonObject customer1Update = JsonParser.parseString("{\"account_id\" : 1121345, \"event_date\": \"2017-08-24\", \"account_standing\": \"G\", \"account_information\":\n" +
                "{\"first_name\": \"John\", \"last_name\": \"Doe\", \"date_of_birth\": \"1986-08-18\", \"address\": {\"street_number\": \"123\",\n" +
                "\"street_name\": \"Main Street\", \"city\": \"Centerville\", \"state\": \"CA\", \"zip_code\": \"91111\"}, \"email_address\":\n" +
                "\"john_doe@gmail1.com\"}}").getAsJsonObject();

        assertTrue(accountRepo.add(customer1Update));

        JsonObject updatedInfo = accountRepo.recentUpdate(1121345);
        assertEquals("john_doe@gmail1.com", updatedInfo.get("account_information").getAsJsonObject().get("email_address").getAsString());
    }
}
